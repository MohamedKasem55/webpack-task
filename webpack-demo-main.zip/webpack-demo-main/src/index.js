import hello from './hellow wolrd.js';
hello()
import './component/header/header'
import './component/bio/bio.js';
import './style.css';


